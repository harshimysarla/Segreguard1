# SegreGuard Web Starter

A minimal, runnable starter for the Smart Waste Segregation project.

## Stack
- **Backend**: Django + Django REST Framework (SQLite for dev)
- **Frontend**: React (Vite) + TailwindCSS
- **Endpoints**: `/api/scans/`, `/api/centers/`, `/api/rewards/`, `/api/scans/impact/`

> The classifier is a simple filename keyword demo (e.g., upload `banana.jpg`, `bottle.png`, `battery.jpeg`) to simulate categories. Replace with a real ML model when ready.

---

## Running locally

### 1) Backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt

python manage.py migrate
python manage.py createsuperuser --username admin --email admin@example.com
python manage.py runserver 0.0.0.0:8000
```

Seed some data (optional):
```bash
# In Django admin at http://localhost:8000/admin add a few Centers and Rewards
```

### 2) Frontend
```bash
cd ../frontend
npm install
npm run dev
```
Visit: `http://localhost:5173`

The dev server proxies `/api` to `http://localhost:8000`.

---

## Replacing the demo classifier

- Implement your TF/TFLite/ONNX model in `waste/views.py#create`:
  - Load model at module import
  - Preprocess the uploaded image
  - Run inference
  - Map logits → labels: `['biodegradable','plastic','glass','metal','paper','hazardous']`
- Or move inference to the browser with TensorFlow.js.

---

## Project structure

```
segreguard-web/
  backend/
    eco_backend/
    waste/
    manage.py
    requirements.txt
  frontend/
    index.html
    vite.config.js
    src/
      pages/
      main.jsx
      index.css
    package.json
    tailwind.config.js
    postcss.config.js
  README.md
```

---

## Notes
- This is a minimal scaffold focused on getting you productive immediately.
- Add auth (JWT), file size limits, and CORS rules for production.
- For production DB, switch SQLite → Postgres in `eco_backend/settings.py`.
