from django.contrib import admin
from .models import Center, Reward, Scan

admin.site.register(Center)
admin.site.register(Reward)
admin.site.register(Scan)
