from django.db import models
from django.contrib.auth.models import User

MATERIAL_CHOICES = [
    ('biodegradable', 'Biodegradable'),
    ('plastic', 'Plastic'),
    ('glass', 'Glass'),
    ('metal', 'Metal'),
    ('paper', 'Paper'),
    ('hazardous', 'Hazardous'),
]

class Center(models.Model):
    name = models.CharField(max_length=120)
    address = models.TextField()
    lat = models.FloatField()
    lon = models.FloatField()
    contact = models.CharField(max_length=50, blank=True)
    accepted_materials = models.JSONField(default=list)

    def __str__(self):
        return self.name

class Reward(models.Model):
    title = models.CharField(max_length=120)
    points_needed = models.PositiveIntegerField(default=50)
    partner = models.CharField(max_length=120, blank=True)

    def __str__(self):
        return f"{self.title} ({self.points_needed} pts)"

class Scan(models.Model):
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    image = models.ImageField(upload_to='scans/')
    label = models.CharField(max_length=32, choices=MATERIAL_CHOICES)
    confidence = models.FloatField(default=0.9)
    points_awarded = models.IntegerField(default=5)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.label} ({self.confidence:.2f})"
