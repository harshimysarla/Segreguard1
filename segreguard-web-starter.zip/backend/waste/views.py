from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from django.db.models import Sum
from .models import Scan, Center, Reward, MATERIAL_CHOICES
from .serializers import ScanSerializer, CenterSerializer, RewardSerializer

# --- naive demo classifier: label by filename keyword ---
def classify_filename(name: str):
    n = (name or '').lower()
    mapping = {
        'banana': 'biodegradable',
        'food': 'biodegradable',
        'apple': 'biodegradable',
        'bottle': 'plastic',
        'plastic': 'plastic',
        'glass': 'glass',
        'jar': 'glass',
        'can': 'metal',
        'metal': 'metal',
        'paper': 'paper',
        'card': 'paper',
        'battery': 'hazardous',
        'paint': 'hazardous',
        'chem': 'hazardous',
    }
    for k, v in mapping.items():
        if k in n:
            return v, 0.96
    return 'plastic', 0.72

class ScanViewSet(viewsets.ModelViewSet):
    queryset = Scan.objects.all().order_by('-created_at')
    serializer_class = ScanSerializer

    def create(self, request, *args, **kwargs):
        file = request.FILES.get('image')
        if not file:
            return Response({'detail':'image is required'}, status=400)
        label, conf = classify_filename(getattr(file, 'name', ''))
        scan = Scan.objects.create(image=file, label=label, confidence=conf, user=request.user if request.user.is_authenticated else None)
        return Response(ScanSerializer(scan).data, status=status.HTTP_201_CREATED)

    @action(detail=False, methods=['get'])
    def impact(self, request):
        pts = Scan.objects.aggregate(total=Sum('points_awarded'))['total'] or 0
        counts = {k: Scan.objects.filter(label=k).count() for k,_ in MATERIAL_CHOICES}
        # very rough demo factor for CO2 saved
        co2_factors = {'plastic':1.5,'glass':0.3,'metal':2.0,'paper':1.0,'biodegradable':0.0,'hazardous':0.0}
        co2 = sum(counts[m]*co2_factors.get(m,0) for m in counts)
        return Response({'points_total': pts, 'counts': counts, 'co2_saved_kg': co2})

class CenterViewSet(viewsets.ModelViewSet):
    queryset = Center.objects.all()
    serializer_class = CenterSerializer

class RewardViewSet(viewsets.ModelViewSet):
    queryset = Reward.objects.all()
    serializer_class = RewardSerializer
