import { useEffect, useState } from 'react'
import axios from 'axios'

export default function Centers() {
  const [centers, setCenters] = useState([])

  useEffect(()=>{
    axios.get('/api/centers/').then(res=>setCenters(res.data))
  }, [])

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold">Recycling Centers</h2>
      <p className="text-sm text-gray-500">Seed some sample centers in the admin or via API.</p>
      <div className="grid md:grid-cols-2 gap-4">
        {centers.map(c => (
          <div key={c.id} className="border rounded p-4">
            <h3 className="font-semibold">{c.name}</h3>
            <p className="text-sm">{c.address}</p>
            <p className="text-sm">Contact: {c.contact || 'N/A'}</p>
            <p className="text-sm mt-2"><span className="font-semibold">Accepted:</span> {Array.isArray(c.accepted_materials) ? c.accepted_materials.join(', ') : '—'}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
