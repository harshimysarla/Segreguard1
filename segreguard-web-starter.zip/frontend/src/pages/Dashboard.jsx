import { useEffect, useState } from 'react'
import axios from 'axios'

export default function Dashboard() {
  const [impact, setImpact] = useState(null)

  useEffect(()=>{
    axios.get('/api/scans/impact/').then(res=>setImpact(res.data))
  }, [])

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold">Impact Dashboard</h2>
      {!impact ? <p>Loading...</p> : (
        <div className="space-y-2">
          <p><span className="font-semibold">Total Points:</span> {impact.points_total}</p>
          <p><span className="font-semibold">CO₂ Saved:</span> {impact.co2_saved_kg.toFixed(2)} kg</p>
          <div className="grid sm:grid-cols-3 md:grid-cols-6 gap-2">
            {Object.entries(impact.counts).map(([k,v])=> (
              <div key={k} className="border rounded p-3 text-center">
                <div className="text-sm text-gray-500">{k}</div>
                <div className="text-2xl font-bold">{v}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
