import { Link } from 'react-router-dom'

export default function Home() {
  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-semibold">Welcome to SegreGuard</h2>
      <p>Classify waste, find nearby recycling centers, earn eco-rewards, and track your impact.</p>
      <Link to="/scan" className="inline-block bg-green-600 text-white px-4 py-2 rounded">Start Scanning</Link>
    </div>
  )
}
