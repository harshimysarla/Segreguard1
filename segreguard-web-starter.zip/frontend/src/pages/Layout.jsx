import { Link, Outlet, useLocation } from 'react-router-dom'

export default function Layout() {
  const loc = useLocation()
  const nav = [
    ['/', 'Home'],
    ['/scan', 'Scan'],
    ['/centers', 'Centers'],
    ['/rewards', 'Rewards'],
    ['/dashboard', 'Dashboard'],
  ]
  return (
    <div className="min-h-screen">
      <header className="bg-green-600 text-white">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
          <h1 className="font-bold text-xl">SegreGuard</h1>
          <nav className="flex gap-4">
            {nav.map(([to, label]) => (
              <Link key={to}
                to={to}
                className={`px-3 py-1 rounded ${loc.pathname===to ? 'bg-green-700' : 'hover:bg-green-700'}`}>
                {label}
              </Link>
            ))}
          </nav>
        </div>
      </header>
      <main className="max-w-5xl mx-auto px-4 py-8">
        <Outlet />
      </main>
      <footer className="text-center text-sm text-gray-500 py-6">© {new Date().getFullYear()} SegreGuard</footer>
    </div>
  )
}
