import { useEffect, useState } from 'react'
import axios from 'axios'

export default function Rewards() {
  const [rewards, setRewards] = useState([])

  useEffect(()=>{
    axios.get('/api/rewards/').then(res=>setRewards(res.data))
  }, [])

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold">Eco-Rewards</h2>
      <div className="grid md:grid-cols-2 gap-4">
        {rewards.map(r => (
          <div key={r.id} className="border rounded p-4">
            <h3 className="font-semibold">{r.title}</h3>
            <p className="text-sm">Partner: {r.partner || '—'}</p>
            <p className="text-sm">Points needed: {r.points_needed}</p>
            <button className="mt-2 bg-green-600 text-white px-3 py-1 rounded">Redeem</button>
          </div>
        ))}
      </div>
    </div>
  )
}
