import { useState } from 'react'
import axios from 'axios'

export default function Scan() {
  const [file, setFile] = useState(null)
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const submit = async () => {
    if (!file) return
    setLoading(true); setError(null)
    const fd = new FormData()
    fd.append('image', file)
    try {
      const res = await axios.post('/api/scans/', fd)
      setResult(res.data)
    } catch (e) {
      setError('Upload failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold">Upload an item photo</h2>
      <input type="file" accept="image/*" onChange={e=>setFile(e.target.files[0])} />
      <button onClick={submit} className="bg-green-600 text-white px-4 py-2 rounded disabled:opacity-50" disabled={!file || loading}>
        {loading ? 'Classifying...' : 'Upload & Classify'}
      </button>
      {error && <p className="text-red-600">{error}</p>}
      {result && (
        <div className="border rounded p-4">
          <p><span className="font-semibold">Detected:</span> {result.label}</p>
          <p><span className="font-semibold">Confidence:</span> {Math.round(result.confidence*100)}%</p>
          {result.image && <p className="text-sm text-gray-500">Stored: {result.image}</p>}
          <div className="mt-2 text-sm">
            {result.label === 'plastic' && <p>Tip: Rinse, remove cap ring, crush bottle before binning.</p>}
            {result.label === 'glass' && <p>Tip: Rinse, keep whole to avoid shards.</p>}
            {result.label === 'metal' && <p>Tip: Rinse cans; avoid sharp edges.</p>}
            {result.label === 'paper' && <p>Tip: Keep dry and unsoiled.</p>}
            {result.label === 'biodegradable' && <p>Tip: Compostable—use green bin.</p>}
            {result.label === 'hazardous' && <p>Tip: Take to a hazardous/e-waste counter.</p>}
          </div>
        </div>
      )}
    </div>
  )
}
